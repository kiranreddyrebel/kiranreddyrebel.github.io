import http.server
import socketserver
import urllib.parse
import requests
import threading

PORT = 8080
httpd = None  # Global server instance
server_thread = None

DEFAULT_HEADERS = {
    "authority": "z5ak-cmaflive.zee5.com",
    "accept": "*/*",
    "accept-encoding": "gzip, deflate, br, zstd",
    "accept-language": "en-US,en;q=0.9",
    "origin": "https://www.zee5.com",
    "priority": "u=1, i",
    "referer": "https://www.zee5.com/",
    "sec-ch-ua": '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
}

class Zee5ProxyHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed_url.query)

        if parsed_url.path != "/zee5-proxy" or "url" not in query:
            self.send_error(400, "Missing or invalid 'url' parameter")
            return

        target_url = query["url"][0]

        try:
            res = requests.get(target_url, headers=DEFAULT_HEADERS, timeout=15)
        except Exception as e:
            self.send_error(502, f"Request failed: {e}")
            return

        content_type = res.headers.get("Content-Type", "")
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        # Check if this is a playlist
        if "#EXTM3U" in res.text or content_type.endswith("mpegurl"):
            base_url = target_url.rsplit("/", 1)[0]

            def rewrite(line):
                line = line.strip()
                # URI="..."
                if 'URI="' in line:
                    start = line.find('URI="') + 5
                    end = line.find('"', start)
                    uri_val = line[start:end]
                    abs_uri = urllib.parse.urljoin(base_url + "/", uri_val)
                    proxied = f"/zee5-proxy?url={urllib.parse.quote(abs_uri, safe=':/?&=~')}"
                    print(f"🔄 Rewriting URI: {uri_val} → {proxied}")
                    return line[:start] + proxied + line[end:]

                # .m3u8, .ts, .mp4 direct or query-variants
                if any(ext in line for ext in [".m3u8", ".ts", ".mp4"]) and not line.startswith("#"):
                    abs_uri = urllib.parse.urljoin(base_url + "/", line)
                    proxied = f"/zee5-proxy?url={urllib.parse.quote(abs_uri, safe=':/?&=~')}"
                    print(f"🔁 Proxying: {line} → {proxied}")
                    return proxied

                return line

            playlist_lines = res.text.splitlines()
            rewritten = "\n".join([rewrite(line) for line in playlist_lines])
            self.wfile.write(rewritten.encode("utf-8"))
        else:
            # Serve binary segments (ts/mp4)
            self.wfile.write(res.content)

# === START/STOP SERVER FUNCTIONS ===

def start_proxy_server():
    global httpd, server_thread
    if httpd is not None:
        print("⚠️ Server is already running.")
        return

    def server_target():
        global httpd
        with socketserver.ThreadingTCPServer(("", PORT), Zee5ProxyHandler) as httpd_instance:
            httpd = httpd_instance
            print(f"🌀 Zee5 proxy running at: http://localhost:{PORT}/zee5-proxy?url=<your-url>")
            httpd.serve_forever()

    server_thread = threading.Thread(target=server_target, daemon=True)
    server_thread.start()

def stop_proxy_server():
    global httpd
    if httpd:
        print("🛑 Stopping proxy server...")
        httpd.shutdown()
        httpd = None
    else:
        print("⚠️ Proxy server is not running.")

# === MAIN TEST ENTRY POINT ===
if __name__ == "__main__":
    start_proxy_server()
    try:
        while True:
            pass  # Keep running
    except KeyboardInterrupt:
        stop_proxy_server()
